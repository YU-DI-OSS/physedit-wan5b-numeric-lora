# Make sure to modify __release_datetime__ to release time when making official release.
__version__ = '2.1.9'
# default release datetime for branches under active development is set
# to be a time far-far-away-into-the-future
__release_datetime__ = '2099-10-13 08:56:12'